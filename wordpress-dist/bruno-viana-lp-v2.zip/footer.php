<footer class="footer">
    <div class="container">
        <p>&copy;
            <?php echo date('Y'); ?> Bruno Viana. Todos os direitos reservados.
        </p>
    </div>
</footer>

<div id="particles-js" class="global-bg-effect"></div>

<?php wp_footer(); ?>
</body>

</html>